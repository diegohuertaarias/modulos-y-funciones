class Producto:
    def __int__(self, nombre, unidades):
        self.nombre=nombre
        self.unidades=unidades

alumnos={}
Asignaturas=[]
calificaciones=()



def calcular_cuadrado():
    print("calcular_cuadrado")
def calcular_cubo():
    print("calcular cubo")