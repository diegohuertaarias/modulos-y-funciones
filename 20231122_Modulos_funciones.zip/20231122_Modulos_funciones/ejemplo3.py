
argentina={
    "portero":"fribu",
    "defensas":["pasarela","el otro","el del moto"],
    "medios":False,
    "Delanteros":"maradona"
}
brasil={
    "portero":"fulaniho",
    "defensas":["roberto carlos","marcelo","otro"],
    "medios":"zico",
    "Delanteros":"ronaldo el rodillas"
}
class Pais:
    def __int__(self, nombre, capital):
        self.nombre=nombre
        self.capital=capital

class Coche:
    def __init__(self, marca,modelo):
        self.marca=marca
        self.modelo=modelo