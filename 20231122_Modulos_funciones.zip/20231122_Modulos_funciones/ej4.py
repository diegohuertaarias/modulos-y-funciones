from simulacionexamen import silla, color

def main():
    try:
        # Crear dos sillas
        silla_azul = silla(color.AZUL, 9.95)
        silla_roja = silla(color.ROJO, 9.95)

        # Mostrar la información de las sillas
        print(f"Silla Azul - Color: {silla_azul.color.value}, Precio: ${silla_azul.precio}")
        print(f"Silla Roja - Color: {silla_roja.color.value}, Precio: ${silla_roja.precio}")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()
