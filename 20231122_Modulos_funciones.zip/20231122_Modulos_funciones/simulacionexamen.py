from datetime import datetime
from enum import Enum
#actividad1
def suma_numeros():
    numeros = []

    try:
        for _ in range(5):  # Limitar a un máximo de 5 números
            entrada = input("Introduce un número (q para salir): ")

            if entrada.lower() == 'q':
                break

            convertir_a_numero = lambda x: float(x)
            numero = convertir_a_numero(entrada)

            numeros.append(numero)

    except ValueError:
        print("Error: Por favor, introduce un número válido.")
        return None

    suma = lambda x: sum(x)
    return suma(numeros)

# Ejecutar la función y mostrar el resultado
resultado = suma_numeros()

if resultado is not None:
    print(f"La suma de los números introducidos es: {resultado}")
#Actividad 2

from datetime import datetime

def calcular_descuento():
    # Obtener la fecha actual
    fecha_actual = datetime.now()

    # Obtener el día del mes
    dia_del_mes = fecha_actual.day

    # Determinar si el día es anterior al 15
    es_anterior_al_15 = dia_del_mes < 15

    # Calcular el descuento
    descuento = 0.05 if es_anterior_al_15 else 0.0

    return descuento

def calcular_total(unidades, precio):
    # Calcular el subtotal
    subtotal = unidades * precio

    # Obtener el descuento
    descuento = calcular_descuento()

    # Aplicar el descuento al subtotal
    total = subtotal - (subtotal * descuento)

    return total

# Solicitar al usuario las unidades y el precio
try:
    unidades = float(input("Introduce la cantidad de unidades: "))
    precio = float(input("Introduce el precio por unidad: "))

    # Calcular el total de la factura
    total_factura = calcular_total(unidades, precio)

    # Mostrar el total de la factura
    print(f"Total de la factura: {total_factura}")

except ValueError:
    print("Error: Por favor, introduce valores numéricos válidos para unidades y precio.")
#Actividad 3
def numeros_pares_entre(inicial, final):
    # Utilizando una lista de comprensión para generar los números pares entre inicial y final
    pares = [num for num in range(inicial, final + 1) if num % 2 == 0]
    return pares

# Solicitar al usuario el número inicial y final
try:
    numero_inicial = int(input("Introduce el número inicial: "))
    numero_final = int(input("Introduce el número final: "))

    # Verificar que el número final sea mayor o igual al número inicial
    if numero_final < numero_inicial:
        print("Error: El número final debe ser mayor o igual al número inicial.")
    else:
        # Obtener la lista de números pares
        lista_pares = numeros_pares_entre(numero_inicial, numero_final)

        # Mostrar la lista de números pares
        print(f"Números pares entre {numero_inicial} y {numero_final}: {lista_pares}")

except ValueError:
    print("Error: Por favor, introduce números enteros válidos.")
#actividad 4
"""Crea un módulo con las siguientes clases
Mesa
Silla
Lampara
las tres clases tiene como atributo color y precio.
En otro módulo importa únicamente la clase Silla y crea dos sillas. Una de color azul y otra roja con precios de 9.95

algoritmo funciona:5 puntos
algoritmo utiliza características de POO : 5 puntos
algoritmo controla errores y excepciones : 5 puntos
algoritmo aplica enumeradores o similar para Color : 5 puntos
algoritmo resuelve una mejora de funcionalidad : 5 puntos"""
class color(Enum):
    AZUL = "azul"
    ROJO = "rojo"
class Mesa():
    def __init__(self, color, precio):
        self.color=color
        self.precio=precio
class silla():
    def __init__(self, color, precio):
        self.color=color
        self.precio=precio

class lampara():
    def __init__(self, color, precio):
        self.color=color
        self.precio=precio



